/**
 * Clase Proyectocorte2backApplicationTests
 * Proyecto: proyectocorte2back
 * Paquete: co.edu.unbosque.proyectocorte2back
 *
 * Descripción: Documentación pendiente.
 */
package co.edu.unbosque.proyectocorte2back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// TODO: Auto-generated Javadoc
/**
 * The Class Proyectocorte2backApplicationTests.
 */
@SpringBootTest
class Proyectocorte2backApplicationTests {

	/**
	 * Context loads.
	 */
	@Test
	void contextLoads() {
	}

}
