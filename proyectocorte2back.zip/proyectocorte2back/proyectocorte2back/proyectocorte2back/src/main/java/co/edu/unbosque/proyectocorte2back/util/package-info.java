/**
 * Contiene clases utilitarias y funciones auxiliares que
 * apoyan otras partes del sistema.
 */
package co.edu.unbosque.proyectocorte2back.util;
