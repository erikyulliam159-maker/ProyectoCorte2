/**
 * Contiene los controladores REST que manejan las solicitudes HTTP
 * y definen los endpoints de la aplicación.
 */
package co.edu.unbosque.proyectocorte2back.controller;
