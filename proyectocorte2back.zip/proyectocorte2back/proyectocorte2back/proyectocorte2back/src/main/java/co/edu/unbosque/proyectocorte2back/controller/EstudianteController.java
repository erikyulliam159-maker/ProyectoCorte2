/**
 * Clase EstudianteController
 * Proyecto: proyectocorte2back
 * Paquete: co.edu.unbosque.proyectocorte2back.controller
 *
 * Descripción: Documentación pendiente.
 */
package co.edu.unbosque.proyectocorte2back.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import co.edu.unbosque.proyectocorte2back.dto.TemarioDTO;
import co.edu.unbosque.proyectocorte2back.dto.SubtemaDTO;
import co.edu.unbosque.proyectocorte2back.dto.DetalleSubtemaDTO;
import co.edu.unbosque.proyectocorte2back.dto.ProblemaDTO;
import co.edu.unbosque.proyectocorte2back.dto.LibroDTO;
import co.edu.unbosque.proyectocorte2back.dto.EventoDTO;
import co.edu.unbosque.proyectocorte2back.dto.LinkValiosoDTO;
import co.edu.unbosque.proyectocorte2back.services.TemarioService;
import co.edu.unbosque.proyectocorte2back.util.ArchivoUtil;
import co.edu.unbosque.proyectocorte2back.services.SubtemaService;
import co.edu.unbosque.proyectocorte2back.services.DetalleSubtemaService;
import co.edu.unbosque.proyectocorte2back.services.ProblemaService;
import co.edu.unbosque.proyectocorte2back.services.LibroService;
import co.edu.unbosque.proyectocorte2back.services.EventoService;
import co.edu.unbosque.proyectocorte2back.services.LinkValiosoService;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

// TODO: Auto-generated Javadoc
/**
 * The Class EstudianteController.
 */
@RestController
@RequestMapping("/estudiante")
@CrossOrigin(origins = { "*" })
public class EstudianteController {

    /** The temario service. */
    @Autowired
    private TemarioService temarioService;

    /** The subtema service. */
    @Autowired
    private SubtemaService subtemaService;

    /** The detalle subtema service. */
    @Autowired
    private DetalleSubtemaService detalleSubtemaService;

    /** The problema service. */
    @Autowired
    private ProblemaService problemaService;

    /** The libro service. */
    @Autowired
    private LibroService libroService;

    /** The evento service. */
    @Autowired
    private EventoService eventoService;

    /** The link valioso service. */
    @Autowired
    private LinkValiosoService linkValiosoService;
    
    /** The archivo util. */
    @Autowired
    private ArchivoUtil archivoUtil;

  
    /**
     * Gets the all temarios.
     *
     * @return the all temarios
     */
    @GetMapping("/temario/getall")
    public ResponseEntity<List<TemarioDTO>> getAllTemarios() {
        List<TemarioDTO> temarios = temarioService.getAll();
        if (temarios.isEmpty()) {
            return new ResponseEntity<>(temarios, HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(temarios, HttpStatus.OK);
        }
    }

    /**
     * Gets the temario by id.
     *
     * @param id the id
     * @return the temario by id
     */
    @GetMapping("/temario/getbyid/{id}")
    public ResponseEntity<TemarioDTO> getTemarioById(@PathVariable Long id) {
        TemarioDTO temario = temarioService.getById(id);
        if (temario != null) {
            return new ResponseEntity<>(temario, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Gets the all subtemas.
     *
     * @return the all subtemas
     */
    // Ver subtemas
    @GetMapping("/subtema/getall")
    public ResponseEntity<List<SubtemaDTO>> getAllSubtemas() {
        List<SubtemaDTO> subtemas = subtemaService.getAll();
        if (subtemas.isEmpty()) {
            return new ResponseEntity<>(subtemas, HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(subtemas, HttpStatus.OK);
        }
    }

    /**
     * Gets the subtema by id.
     *
     * @param id the id
     * @return the subtema by id
     */
    @GetMapping("/subtema/getbyid/{id}")
    public ResponseEntity<SubtemaDTO> getSubtemaById(@PathVariable Long id) {
        SubtemaDTO subtema = subtemaService.getById(id);
        if (subtema != null) {
            return new ResponseEntity<>(subtema, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Gets the all detalles subtema.
     *
     * @return the all detalles subtema
     */
    // Ver detalle subtema
    @GetMapping("/detallesubtema/getall")
    public ResponseEntity<List<DetalleSubtemaDTO>> getAllDetallesSubtema() {
        List<DetalleSubtemaDTO> detalles = detalleSubtemaService.getAll();
        if (detalles.isEmpty()) {
            return new ResponseEntity<>(detalles, HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(detalles, HttpStatus.OK);
        }
    }

    /**
     * Gets the detalle subtema by id.
     *
     * @param id the id
     * @return the detalle subtema by id
     */
    @GetMapping("/detallesubtema/getbyid/{id}")
    public ResponseEntity<DetalleSubtemaDTO> getDetalleSubtemaById(@PathVariable Long id) {
        DetalleSubtemaDTO detalle = detalleSubtemaService.getById(id);
        if (detalle != null) {
            return new ResponseEntity<>(detalle, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }


    /**
     * Gets the all problemas.
     *
     * @return the all problemas
     */
    @GetMapping("/problema/getall")
    public ResponseEntity<List<ProblemaDTO>> getAllProblemas() {
        List<ProblemaDTO> problemas = problemaService.getAll();
        if (problemas.isEmpty()) {
            return new ResponseEntity<>(problemas, HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(problemas, HttpStatus.OK);
        }
    }

    /**
     * Gets the problema by id.
     *
     * @param id the id
     * @return the problema by id
     */
    @GetMapping("/problema/getbyid/{id}")
    public ResponseEntity<ProblemaDTO> getProblemaById(@PathVariable Long id) {
        ProblemaDTO problema = problemaService.getById(id);
        if (problema != null) {
            return new ResponseEntity<>(problema, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }


    /**
     * Gets the all libros.
     *
     * @return the all libros
     */
    @GetMapping("/libro/getall")
    public ResponseEntity<List<LibroDTO>> getAllLibros() {
        List<LibroDTO> libros = libroService.getAll();
        if (libros.isEmpty()) {
            return new ResponseEntity<>(libros, HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(libros, HttpStatus.OK);
        }
    }

    /**
     * Download pdf.
     *
     * @param id the id
     * @return the response entity
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @GetMapping("/libro/downloadpdf/{id}")
    public ResponseEntity<InputStreamResource> downloadPdf(@PathVariable Long id) throws IOException {
        LibroDTO libro = libroService.getById(id);
        if (libro == null || libro.getPdf() == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        File archivo = archivoUtil.obtenerArchivo(libro.getPdf());
        if (!archivo.exists()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        InputStreamResource resource = new InputStreamResource(new FileInputStream(archivo));
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + archivo.getName())
                .contentType(MediaType.APPLICATION_PDF)
                .contentLength(archivo.length())
                .body(resource);
    }

    
    

    /**
     * Gets the all eventos.
     *
     * @return the all eventos
     */
    @GetMapping("/evento/getall")
    public ResponseEntity<List<EventoDTO>> getAllEventos() {
        List<EventoDTO> eventos = eventoService.getAll();
        if (eventos.isEmpty()) {
            return new ResponseEntity<>(eventos, HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(eventos, HttpStatus.OK);
        }
    }

    /**
     * Gets the evento by id.
     *
     * @param id the id
     * @return the evento by id
     */
    @GetMapping("/evento/getbyid/{id}")
    public ResponseEntity<EventoDTO> getEventoById(@PathVariable Long id) {
        EventoDTO evento = eventoService.getById(id);
        if (evento != null) {
            return new ResponseEntity<>(evento, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }


    /**
     * Gets the all links valiosos.
     *
     * @return the all links valiosos
     */
    @GetMapping("/linkvalioso/getall")
    public ResponseEntity<List<LinkValiosoDTO>> getAllLinksValiosos() {
        List<LinkValiosoDTO> links = linkValiosoService.getAll();
        if (links.isEmpty()) {
            return new ResponseEntity<>(links, HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(links, HttpStatus.OK);
        }
    }

    /**
     * Gets the link valioso by id.
     *
     * @param id the id
     * @return the link valioso by id
     */
    @GetMapping("/linkvalioso/getbyid/{id}")
    public ResponseEntity<LinkValiosoDTO> getLinkValiosoById(@PathVariable Long id) {
        LinkValiosoDTO link = linkValiosoService.getById(id);
        if (link != null) {
            return new ResponseEntity<>(link, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }
    
    /**
     * Download temario pdf.
     *
     * @return the response entity
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @GetMapping("/temario/downloadpdf")
    public ResponseEntity<byte[]> downloadTemarioPdf() throws IOException {
        List<TemarioDTO> temarios = temarioService.getAll();
        byte[] pdfBytes = archivoUtil.generarPdfTemario(temarios);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=temarios.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }

    /**
     * Download problemas pdf.
     *
     * @return the response entity
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @GetMapping("/problema/downloadpdf")
    public ResponseEntity<byte[]> downloadProblemasPdf() throws IOException {
        List<ProblemaDTO> problemas = problemaService.getAll();
        byte[] pdfBytes = archivoUtil.generarPdfProblemas(problemas);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=problemas.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }

    /**
     * Download libros pdf.
     *
     * @return the response entity
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @GetMapping("/libro/downloadpdf")
    public ResponseEntity<byte[]> downloadLibrosPdf() throws IOException {
        List<LibroDTO> libros = libroService.getAll();
        byte[] pdfBytes = archivoUtil.generarPdfLibros(libros);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=libros.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}