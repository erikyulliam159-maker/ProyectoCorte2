/**
 * Contiene las clases DTO (Data Transfer Object) utilizadas para
 * transferir datos entre capas sin exponer las entidades directamente.
 */
package co.edu.unbosque.proyectocorte2back.dto;
