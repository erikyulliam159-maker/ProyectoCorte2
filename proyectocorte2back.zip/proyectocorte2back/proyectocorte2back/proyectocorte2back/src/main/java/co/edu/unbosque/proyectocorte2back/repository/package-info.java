/**
 * Contiene las interfaces de repositorio que extienden JPA o CRUD Repository
 * para realizar operaciones con la base de datos.
 */
package co.edu.unbosque.proyectocorte2back.repository;
