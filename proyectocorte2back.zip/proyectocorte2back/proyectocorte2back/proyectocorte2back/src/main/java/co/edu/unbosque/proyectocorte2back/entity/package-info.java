/**
 * Contiene las entidades del modelo de datos que representan
 * las tablas de la base de datos.
 */
package co.edu.unbosque.proyectocorte2back.entity;
