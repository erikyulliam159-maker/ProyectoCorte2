/**
 * Paquete principal del proyecto backend para el corte 2.
 * Contiene la estructura base y los subpaquetes del sistema.
 */
package co.edu.unbosque.proyectocorte2back;
