/**
 * Contiene las clases de configuración del proyecto,
 * como beans, seguridad, y propiedades personalizadas.
 */
package co.edu.unbosque.proyectocorte2back.configure;
