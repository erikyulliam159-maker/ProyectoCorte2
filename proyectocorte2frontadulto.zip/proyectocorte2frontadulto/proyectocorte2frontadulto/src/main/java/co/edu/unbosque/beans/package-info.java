/**
 * Este paquete contiene las clases JavaBeans utilizadas 
 * para representar datos y encapsular la lógica básica 
 * de propiedades. 
 * 
 * Los beans suelen ser usados en la capa de presentación 
 * para transferir información entre la vista y el modelo.
 */
package co.edu.unbosque.beans;
