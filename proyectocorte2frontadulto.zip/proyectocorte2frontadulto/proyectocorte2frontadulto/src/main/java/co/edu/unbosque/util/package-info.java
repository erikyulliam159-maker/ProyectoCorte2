/**
 * Este paquete contiene clases y utilidades de apoyo. 
 * 
 * Incluye funciones auxiliares, validaciones, conversiones 
 * y cualquier componente reutilizable en distintas capas 
 * de la aplicación.
 */
package co.edu.unbosque.util;
